<div class="ticker-wrapper">
<div class="bigHeading">Breaking News</div>
<div class="text-update">

Coronavirus live updates: China reports no deaths for the first time

</div>
</div>
</div>