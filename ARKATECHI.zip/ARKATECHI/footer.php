<footer>
    <!-- <div class="container"> -->
        <div class="row">
            <div class="col-lg-4">
                <div class="_kl_de_w">
                    <img src="assets/images/logo.png"class="footerlogoimg">
                    <p>Waiting for an opportunity in the IT world?<br> let’s walk together and make it possible for your
                         bright and lightning carrier.</p>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="_kl_de_w">
                    <h3>Quick Links</h3>
                    <ol>
                        <li><i class="far fa-angle-right"></i><a href="index.php">Home</a></li>
                        <!-- <li><i class="far fa-angle-right"></i>About Us</li> -->
                        <li><i class="far fa-angle-right"></i><a href="services.php">Services</a></li>
                        <li class="last"><i class="far fa-angle-right"></i><a href="contact-us.php">Contact Us</a></li>
                    </ol>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="_kl_de_w">
                    <h3>Featured Courses</h3>
                    <ol>
                        <li><i class="far fa-angle-right"></i>CCNA (Routing&Switching)</li>
                        <li><i class="far fa-angle-right"></i>CCNA (Securities)</li>
                        <li class="last"><i class="far fa-angle-right"></i>Firewall</li>
                        <!--  <li class="last"><i class="far fa-angle-right"></i>SDWAN</li> -->
                    </ol>
                </div>
            </div>
        </div>
    <!-- </div> -->


</footer>
<div style="width:60px;hight:60px;position: fixed;right:10px;bottom: 10px;">
<a href="https://wa.me/919689190202" target="_blank"><img src="assets/images/whatsapp.png" style="width:90px;hight:90px;"/> 
</i></a>
</div>


<div class="end-footer">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="last-card">
                    <p>© 2022 All Rights Reserved by<a href="#">ArkaTechi</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<!-- <script src="assets/js/plugins/script.js"></script> -->