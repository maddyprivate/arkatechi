<header>
<div class="my-nav">
    <!-- <div class="container"> -->
        <div class="row">
            <div class="nav-items">
                <div class="menu-toggle">
                    <div class="menu-hamburger"></div>
                </div>
                <div class="logo">
                    <img src="assets/images/logo.png"class="logoimg">
                </div>
                <div class="menu-items">
                    <div class="menu">
                        <ul>
                            <li><a href="index.php">HOME</a></li>
                            <!--<li><a href="about-us.php">About Us</a></li>-->
                            <li><a href="WhyUs.php">WHY US</a></li>
                            <li><a href="services.php">OUR ROADMAP</a></li>
                            <li><a href="contact-us.php">CONTACT US</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <!-- </div> -->
</div>
</header>

<div class="container">
    <div class="ticker">
      <div class="title"><h5>Breaking News</h5></div>
        <div class="news">
          <marquee>
            <p>Admissions closed for batch started on 22nd August 2022. And New batch will start soon.</p>
          </marquee>
        </div>
      </div>
    </div>
</div>
  